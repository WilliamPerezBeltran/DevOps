# Curso de Docker: Fundamentos
Archivos del Curso de Docker: Fundamentos con Amin Espinoza
[Ir al curso](https://platzi.com/cursos/docker-fundamentos/)
